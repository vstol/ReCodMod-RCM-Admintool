<?php
/**
 * Require the library
 */
require 'PHPTail.php';
/**
 * Initilize a new instance of PHPTail
 * @var PHPTail
 */

$tail = new PHPTail(array(
    //"Access_Log" => "access.log",
	"Rifles.1.2" => "/media/Game_Servers/1_2R/ReCodMod/x_logs/chat.log",
	"Rifles.1.1" => "/media/Game_Servers/1_1R/ReCodMod/x_logs/chat.log",
	"Nulled.1.2" => "/media/Game_Servers/1_2N/ReCodMod/x_logs/chat.log",
	"Nulled.1.4" => "/media/Game_Servers/1_4N/ReCodMod/x_logs/chat.log",
	"Rifles.1.4" => "/media/Game_Servers/1_4R/ReCodMod/x_logs/chat.log",		
));

/**
 * We're getting an AJAX call
 */
if(isset($_GET['ajax']))  {
    echo $tail->getNewLines($_GET['file'], $_GET['lastsize'], $_GET['grep'], $_GET['invert']);
    die();
}

/**
 * Regular GET/POST call, print out the GUI
 */
$tail->generateGUI();
