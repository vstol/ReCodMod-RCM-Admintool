<?php
/**
 * Require the library
 */
require 'PHPTail.php';
/**
 * Initilize a new instance of PHPTail
 * @var PHPTail
 */

$tail = new PHPTail(array(
    //"Access_Log" => "access.log",
	"Rifles.1.2" => "./----Cod1_27770/x_logs/rcon-p_chat.log",
	"Rifles.1.1" => "./----Cod1_27772_1.1/x_logs/rcon-p_chat.log",
	"Nulled.1.2" => "./----Cod1_28960_Nulled/x_logs/rcon-p_chat.log",
	"Nulled.1.4" => "./----Cod1_1.4_AW---/x_logs/rcon-p_chat.log",
	"Rifles.1.4" => "./----Cod1_1.4_Rifles/x_logs/rcon-p_chat.log",
	"Rifles.1.5" => "./----Cod1_1.5_Rifles/x_logs/rcon-p_chat.log",
	"Nulled.1.5" => "./____ARHIVE/----Cod1_1.5_AW---new/x_logs/rcon-p_chat.log",		
));

/**
 * We're getting an AJAX call
 */
if(isset($_GET['ajax']))  {
    echo $tail->getNewLines($_GET['file'], $_GET['lastsize'], $_GET['grep'], $_GET['invert']);
    die();
}

/**
 * Regular GET/POST call, print out the GUI
 */
$tail->generateGUI();
