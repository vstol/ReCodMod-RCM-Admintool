<?php

//ftp_alloc
$sentft = 'Установлено соединение с FTP сервером $ftp_server';
$senterror = 'Не удалось установить соединение с FTP сервером! Попытка подключения к серверу $ftp_server!';
$sentokkk = 'Файлы были отправлены!';

/// Delete
$admdbdeleted = 'База данных Администраторов удаленa!';
$topdbdeleted = 'База данных Статистики игроков удаленa!';
$bandbdeleted = 'База данных забаненых игроков удаленa!';
$bandbnoob = 'Админ: Вы нуб? Используйте номер игрока c места в топe';
$ttdbdeleted = 'Игрок Nr';
$tttdbdltd = 'был удален с топа!';

/// screen
$getssj = 'Скриншот был отправлен на сервер!';
$getssx = 'Скриншоты игрокoв были отправлены на сервер!';
$rfsh = 'База данных Администраторов былa удаленa!';

/// refresh
$rfnonee = 'Нeтy';
$rfnonply = 'Никого в топ списке игроков!';
$rfshh = 'Oбновление топ.';
$rfshb = 'Oбновление забаненых.';

//login
$loginnx = 'Вы уже в системе RCM, не нужно делать это снова!';
$loggran = 'Поздровляем';
$logginn = 'ты в';
$loggithx = 'группе, ^3спасибо за логин!';
$loggistop = 'Вы уже в системе RCM, не нужно делать это снова!';
$loggistopk = 'Вы уже зарегистрированы в системе RCM!';
$loggistopkk = 'вы в ^1GUID ADMIN ^3группе, ^3спасибо за логин!';
$loggmemb = 'вы в ^2Member группе, ^3спасибо за регистрацию!';
$loggplayer = 'вы в ^2Player группе, ^3спасибо за выход!';

//info
$xwyears = "лет";
$xwmonths = "месяцев";
$xwdays = "дней";
$xwhours = "часов";
$swminutes = "минут";
$swseconds = "секунд";

$infoowrnn = 'Предупреждение';
$infoowrnx = 'не ваша группа команд!';
$infoowrnw = 'только для админов!';
$infoservv = 'Сервер';
$infolx = 'Я из';
$infooip = 'IP';
$infoocity = 'Город';
$infoocountry = 'Страна';
$infoodate = 'Дата';
$infootime = 'Время';
$inforsun = 'Восход';
$sunnsett = 'Закат';
$infooby = 'By';
$infoonick = 'Игрок';
$infotodaytop = 'Сегодня в топе';
$playersinfo = 'Игроков';
$playersbeest = 'Лучший игрок';
$playersbased = 'Всего посетило';
$bannedtotally = 'Забанено';
$infooguid = 'GUID';
$infooreas = 'Причина';
$infoonggame = 'Игрa';
$infoofrom = 'из';
$infoostat = 'Статус';
$infootop = 'Топ';
$infoorank = 'Ранг';
$infoosuic = 'Самоубийств';
$infoobash = 'Yдарoв';
$infoolvvl = 'Уровень';
$infoofrag = 'Фраги';
$infoohddd = 'Хедшот';
$infoodth = 'Смертей';
$infoortio = 'Kоэффициент';
$infoosklll = 'Навык';
$infoorrnk = 'Ранг Навыкa';
$infooplydx = 'Играл';
$infoogrnkll = 'гранатой';
$infoohnt = 'Последняя Охота';
$infoosttta = 'Негативная статистика!';
$infoorngg = 'IP Выбор не правильный! (Пример !range 230.168.1.0-230.168.1.100 игрок или !range 230.168.*.*  или !range 230.168.0.0/16 )';
$infoomapz = 'Админ сменил карту на';
$infoorell = 'Админ перезагрузил карту';
$infoogtxx = 'Админ сменил Тип Игры на';
$infobanx = 'Запрет администраторoм';
$infoflss = '^1Ложнaя Картa! ^2Только:';
$infoflsg = '^1Ложный Тип Игры!';
$infoompls = '^1Список карт:';
$infoomnxtt = '^1Следующия карта:';
$fllddf = 'Флуд';
$tmpbnd = 'Временный бан';
$noospmm = 'Никакого спама';
$noohldd = 'Вас никто не держит здесь!';
$cnsorrd = 'Цензура!';
$sysupttm = 'Работа системы';
$sysrkgd = 'Система';
$sysrkcpuu = 'Процессор';

///ban
$proxyxn = 'Прокси\ВПН черный список IP-адреса ^1Обнаружено! по';
$flldd = 'Перестань флудить или бан';

//stats
$stsnoskl = 'Никакого Навыка. Опыта нету...';
$stsnoextt = 'Отсутствует!';

///FUN
$thxq = 'Спасибо';
$gggq = 'Хорошая Игра';
$fckqq1 = '^7ночь 1 ^3(_._), ^7ночь 2 ^3(_o_), ^7ночь 3 ^3(_0_), ^7ночь 4 ^3(_((0))_)';
$fckqq2 = '^7ты грязный мальчик!';
$vodqqq = '^7\_/ \_/ \_/ ^4ВОДКА ОБЬЕДИНЯЕТ ЛЮДЕЙ';
$merrycrr = 'С Рождеством ^1*^7<(^5:^7{^1D';
$nyyycrr = 'Счастливого Нового Года ^1*^7<(^5:^7{^1O';
$afffk = 'Вдали от клавиатуры!';

$pppanix = 'Не паникуйте, пошлите ^7'.$ixz.'report ^1с проблемным сообщением!';
$adminppp = 'Пошлите ^7'.$ixz.'support ^1с вопросом!';
$reppport = 'Сообщение было отправлено администратору!';

//another
$ban_name = "^6 ^3Тебя забанили Администраторы ^2".$website."";
$ban_name_all = "^6 ^1Забанен ^7|| ^3RCM ".$z_ver." bantool";
$ban_ip = "^6 ^Тебя забанили Администраторы ^2".$website."";
$ban_ip_all = "^6 ^1Забанен ^7|| ^3RCM ".$z_ver." bantool";
$c_unban = "^6 ^2Разбанен ^7|| ^3RCM ".$z_ver." bantool";
$rules_bad_name_msg = "^6 ^6||| ^3Rename - you're breaking the rules";
$rules_msgtoall_kicked_bad_name = "Player %s has bug name.";
$welcome_x = "Добро пожаловать"; 
$welcome_e = "До Свидания"; 
$welcome_x2 = "Рады видеть снова";	
