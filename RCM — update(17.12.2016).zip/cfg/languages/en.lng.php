<?php

//ftp_alloc
$sentft = 'The link to the FTP server $ftp_server';
$senterror = 'Unable to establish a connection with the FTP server! Trying to connect to the server $ftp_server!';
$sentokkk = 'The files have been sent!';

/// Delete
$admdbdeleted = 'Admin database was deleted!';
$topdbdeleted = 'Player stats database deleted!';
$bandbdeleted = 'Player ban database deleted!';
$bandbnoob = 'Admin you are noob? Use number of player place from !top';
$ttdbdeleted = 'Player Nr';
$tttdbdltd = 'was delete from Top!';

/// refresh
$rfnonee = 'None';
$rfnonply = 'No one in player top list!';
$rfshh = 'Refresh top.';
$rfshb = 'Refresh banlist.';

/// screen
$getssj = 'Screenshot was sent to server!';
$getssx = 'Players Screenshots was sent to server!';
$rfsh = 'Admin database was deleted!';

//login
$loginnx = 'You already in RCM system, dont need do that again!';
$loggran = 'Crangulations';
$logginn = 'you in';
$loggithx = 'group, ^3thanks for login!';
$loggistop = 'You already in RCM system, dont need do that again!';
$loggistopk = 'You already registered in RCM system!';
$loggistopkk = 'you in ^1GUID ADMIN ^3group, ^3thanks for login!';
$loggmemb = 'you in ^2Member group, ^3thanks for registering!';
$loggplayer = 'you in ^2Player group, ^3thanks for quit!';

//info
$xwyears = "years";
$xwmonths = "months";
$xwdays = "days";
$xwhours = "hours";
$swminutes = "minutes";
$swseconds = "seconds";

$infoowrnn = 'WARNING';
$infoowrnx = 'its not your group commands!';
$infoowrnw = 'its only for admins!';
$infoservv = 'Server';
$infolx = 'Iam from';
$infooip = 'IP';
$infoocity = 'City';
$infoocountry = 'Country';
$infoodate = 'Date';
$infootime = 'Time';
$inforsun = 'Sunrise';
$sunnsett = 'Sunset';
$infooby = 'By';
$infoonick = 'Nick';
$infotodaytop = 'Today top';
$playersinfo = 'Players';
$playersbeest = 'Best player';
$playersbased = 'Total visited';
$bannedtotally = 'Banned';
$infooguid = 'Guid';
$infooreas = 'Reason';
$infoonggame = 'Game';
$infoofrom = 'From';
$infoostat = 'Status';
$infootop = 'Top';
$infoorank = 'Rank';
$infoosuic = 'Suicides';
$infoobash = 'Bash';
$infoolvvl = 'Level';
$infoofrag = 'Frags';
$infoohddd = 'HeadShots';
$infoodth = 'Deaths';
$infoortio = 'Ratio';
$infoosklll = 'Skill';
$infoorrnk = 'Skill Rank';
$infooplydx = 'Played';
$infoogrnkll = 'Grenade Kills';
$infoohnt = 'Last Hunt';
$infoosttta = 'Negative stats!';
$infoorngg = 'IP Range is not correct! (EXAMPLE: !range 230.168.1.0-230.168.1.100 OR !range 230.168.*.*  OR !range 230.168.0.0/16 )';
$infoomapz = 'Admin changed map to';
$infoorell = 'Admin reloaded map';
$infoogtxx = 'Admin changed gametype to';
$infobanx = 'BAN By Admin';
$infoflss = '^1False Map! ^2Only:';
$infoflsg = '^1False gametype!';
$infoompls = '^1Maplist:';
$infoomnxtt = '^1Nextmap:';
$fllddf = 'Flooding';
$tmpbnd = 'TEMPBAN';
$noospmm = 'NO Spam';
$noohldd = 'You are no one holds here!';
$cnsorrd = 'Censored!';
$sysupttm = 'System uptime';
$sysrkgd = 'System';
$sysrkcpuu = 'CPU';

///ban
$proxyxn = 'Proxy\VPN Blacklisted IP adress ^1Detected! by';
$flldd = 'Stop chat flooding or BAN';

//stats
$stsnoskl = 'No Skill Rank. Nope experience...';
$stsnoextt = 'Do not exist!';

///FUN
$thxq = 'Thank you too';
$gggq = 'Good Game';
$fckqq1 = '^7night 1 ^3(_._), ^7night 2 ^3(_o_), ^7night 3 ^3(_0_), ^7night 4 ^3(_((0))_)';
$fckqq2 = '^7u dirty boy!';
$vodqqq = '^7\_/ \_/ \_/ ^4VODKA CONNECTING PEOPLE';
$merrycrr = 'Merry Christmas ^1*^7<(^5:^7{^1D';
$nyyycrr = 'Happy New Year ^1*^7<(^5:^7{^1O';
$afffk = 'Away from keyboard!';

$pppanix = 'Do not panic, sent ^7'.$ixz.'report ^1with your problem message!';
$adminppp = 'Sent ^7'.$ixz.'support ^1with your question & in message add your e-mail!';
$reppport = 'Message has been sent to Admin!';

//another
$ban_name = "^6 ^3You Banned by Admins ^2".$website."";
$ban_name_all = "^6 ^1Banned ^7|| ^3RCM ".$z_ver." bantool";
$ban_ip = "^6 ^3You Banned by Admins ^2".$website."";
$ban_ip_all = "^6 ^1Banned ^7|| ^3RCM ".$z_ver." bantool";
$c_unban = "^6 ^2UnBanned ^7|| ^3RCM ".$z_ver." bantool";
$rules_bad_name_msg = "^6 ^6||| ^3Rename - you're breaking the rules";
$rules_msgtoall_kicked_bad_name = "Player %s has bug name.";
$welcome_x = "Welcome";   
$welcome_e = "Bye";
$welcome_x2 = "Welcome Back";	
