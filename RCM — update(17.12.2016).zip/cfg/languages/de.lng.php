<?php
////Translate by ~COP~
//ftp_alloc
$sentft = 'Der Link zum FTP server $ftp_server';
$senterror = 'Es konnte keine Verbindung zu FTP server aufgebaut werden! Probiere zum Server zu verbinden $ftp_server!';
$sentokkk = 'Die Daten wurden gesendet!';

/// Delete
$admdbdeleted = 'Admin Datenbank wurde gelöscht!';
$topdbdeleted = 'Spieler Statistik Datenbank wurde gelöscht!';
$bandbdeleted = 'Spieler Sperrdatenbank wurde gelöscht';
$bandbnoob = 'Admin du bist ein anfänger? Benutze Nummer von Spieler aus der Liste !top';
$ttdbdeleted = 'Spieler Nr';
$tttdbdltd = 'wurde gelöscht von Top!';

/// refresh
$rfnonee = 'Nix';
$rfnonply = 'Kein Spieler in der Topliste!';
$rfshh = 'Aktualisiere Topliste.';
$rfshb = 'Aktualisiere Sperrliste.';

/// screen
$getssj = 'Screenshot wurde an den Server gesendet!';
$getssx = 'Spieler Screenshots wurden an den Server gesendet!';
$rfsh = 'Admin Datenbank wurde gelöscht!';

//login
$loginnx = 'Du bist bereits im RCM System und brauchst dich nicht erneut registrieren!';
$loggran = 'Glückwunsch';
$logginn = 'Du bist in der';
$loggithx = 'Gruppe, ^3danke für den Login!';
$loggistop = 'Du bist bereits im RCM System und brauchst dich nicht erneut registrieren!';
$loggistopk = 'Du bist bereits im RCM System!';
$loggistopkk = 'Du bist in der ^1GUID ADMIN ^3Gruppe, ^3danke für den Login!';
$loggmemb = 'Du bist in der ^2Member Gruppe, ^3danke für die Registrierung!';
$loggplayer = 'Du bist in der ^2Spieler Gruppe, ^3danke fürs verlassen!';

//info
$xwyears = "Jahre";
$xwmonths = "Monate";
$xwdays = "Tage";
$xwhours = "Stunden";
$swminutes = "Minuten";
$swseconds = "Sekunden";

$infoowrnn = 'WARNUNG';
$infoowrnx = 'Dies sind nicht deine Gruppenkommandos!';
$infoowrnw = 'Dies ist nur für Admins!';
$infoservv = 'Server';
$infolx = 'Ich bin aus';
$infooip = 'IP';
$infoocity = 'Stadt';
$infoocountry = 'Land';
$infoodate = 'Datum';
$infootime = 'Zeit';
$inforsun = 'Sonnenaufgang';
$sunnsett = 'Sonnenuntergang';
$infooby = 'von';
$infoonick = 'Nick';
$infotodaytop = 'Heutiger Top';
$playersinfo = 'Spieler';
$playersbeest = 'Bester Spieler';
$playersbased = 'Insgesamt besucht';
$bannedtotally = 'Gesperrt';
$infooguid = 'Guid';
$infooreas = 'Begründung';
$infoonggame = 'Spiel';
$infoofrom = 'Von';
$infoostat = 'Status';
$infootop = 'Top';
$infoorank = 'Rang';
$infoosuic = 'Selbstmorde';
$infoobash = 'Schläge';
$infoolvvl = 'Level';
$infoofrag = 'Frags';
$infoohddd = 'Kopfschüsse';
$infoodth = 'Tode';
$infoortio = 'Verhältnis';
$infoosklll = 'Skill';
$infoorrnk = 'Skill Rang';
$infooplydx = 'Gespielt';
$infoogrnkll = 'Granaten Kills';
$infoohnt = 'Letzte Jagt';
$infoosttta = 'Negative Statistiken!';
$infoorngg = 'IP Bereich ist nicht richtig! (Beispiel: !range 230.168.1.0-230.168.1.100 OR !range 230.168.*.*  OR !range 230.168.0.0/16 )';
$infoomapz = 'Admin ändert die Map zu';
$infoorell = 'Admin lädt die Map neu';
$infoogtxx = 'Admin ändert Spieltyp zu';
$infobanx = 'Gesperrt von Admin';
$infoflss = '^1Falsche Map! ^2Nur:';
$infoflsg = '^1Falscher Spieltyp!';
$infoompls = '^1Mapliste:';
$infoomnxtt = '^1Nächste Map:';
$fllddf = 'Flooding';
$tmpbnd = 'Temporär gesperrt';
$noospmm = 'Kein Spam';
$noohldd = 'Du bist niemand der hier bleibt!';
$cnsorrd = 'Zensiert!';
$sysupttm = 'System Betriebszeit';
$sysrkgd = 'System';
$sysrkcpuu = 'CPU';

///ban
$proxyxn = 'Proxy\VPN schwarz gelistete IP Adresse ^1erkannt! von';
$flldd = 'Stoppe mit dem chat flooding oder du wirst gesperrt';

//stats
$stsnoskl = 'Kein Skill Rang. Keine Erfahrung...';
$stsnoextt = 'Existiert nicht!';

///FUN
$thxq = 'Danke dir auch';
$gggq = 'Gutes Spiel';
$fckqq1 = '^7Nacht 1 ^3(_._), ^7Nacht 2 ^3(_o_), ^7Nacht 3 ^3(_0_), ^7Nacht 4 ^3(_((0))_)';
$fckqq2 = '^7du dreckiger Junge!';
$vodqqq = '^7\_/ \_/ \_/ ^4WODKA VERBINDET MENSCHEN';
$merrycrr = 'Frohe Weihnachten ^1*^7<(^5:^7{^1D';
$nyyycrr = 'Frohes neues Jahr ^1*^7<(^5:^7{^1O';
$afffk = 'Nicht am Computer!';

$pppanix = 'Keine Panik, sende ^7'.$ixz.'report ^1mit deiner problem Nachricht!';
$adminppp = 'Sende ^7'.$ixz.'support ^1mit deiner Frage & deiner E-Mail Adresse!';
$reppport = 'Nachricht wurde an den Admin gesendet!';

//another
$ban_name = "^6 ^3Du wurdest gesperrt von den Admins ^2".$website."";
$ban_name_all = "^6 ^1gesperrt ^7|| ^3RCM ".$z_ver." bantool";
$ban_ip = "^6 ^3Du wurdest gesperrt von den Admins ^2".$website."";
$ban_ip_all = "^6 ^1gesperrt ^7|| ^3RCM ".$z_ver." bantool";
$c_unban = "^6 ^2entsperrt ^7|| ^3RCM ".$z_ver." bantool";
$rules_bad_name_msg = "^6 ^6||| ^3Änder deinen Namen - du brichst die Regeln";
$rules_msgtoall_kicked_bad_name = "Spieler %s hat einen nicht zulässigen Namen.";
$welcome_x = "Willkommen";   
$welcome_e = "Tschüss";
$welcome_x2 = "Willkommen zurück";	
