<?php
if ($x_stop_lp == 0 ) {
if (strpos($msgr, $ixz.'num') !== false)
    { 
 
 $x_namex = clearnamex($i_name);
$x_nickx = clearnamex($nickr);

 echo  $mmm = substr(trim($x_nickx), 0, 2);
 echo  $nnn = substr(trim($x_namex), 0, 2);
	
 if(strpos($nnn, $mmm) !== false)
	     { 
$i_namex = afdasfawf($i_name);	
  $tk = $i_id . ' / ' . $i_namex . ' / ' . $i_ip . ' / ' . $i_ping;
	$kski = explode(" / ", $tk);
			  $newid = $i_id;
			  $newip2 = $i_ip;
/*
try
  {
    $db = new PDO('sqlite:'.$cpath . 'ReCodMod/databases/db1.sqlite');
 
    $result = $db->query("SELECT * FROM x_db_admins WHERE s_adm='$newip2' ");
 		
    foreach($result as $row)
    { 
   $adm_ip  = $row['s_adm'];
    $a_grph  = $row['s_group'];
  $adm_ip = trim($adm_ip);
  $i_ipn = trim($newip2);
//////////////////GROUPS  
  if(($adm_ip == $i_ipn) && ($a_grph == 0) 
  || ($adm_ip == $i_ipn) && ($a_grph == 1)
  || ($adm_ip == $i_ipn) && ($a_grph == '')
  || ($adm_ip == $i_ipn) && ($a_grph == 111)
  || ($adm_ip == $i_ipn) && ($a_grph == 555)
  || ($adm_ip == $i_ipn) && ($a_grph == 2)
  || ($adm_ip == $i_ipn) && ($a_grph == 3)
  || ($adm_ip == $i_ipn) && ($a_grph == 4)
  || ($adm_ip == $i_ipn) && ($a_grph == 5)
  || ($adm_ip == $i_ipn) && ($a_grph == 6)
  || ($adm_ip == $i_ipn) && ($a_grph == 7)
  || ($adm_ip == $i_ipn) && ($a_grph == 8))
	      { 			    	  
		echo '---'.$i_namex.'---';
++$x_number;		
		 }
	}
	
$result = null;
$db = NULL;
 
  }
  catch(PDOException $e)
  {
    print ' FILE:  '.__FILE__.'  Exception : '.$e->getMessage();
  }		
*/	
	
}

	
//if ($x_number > 0){
usleep($sleep_rcon);		 	
require $cpath.'ReCodMod/functions/inc_functions2.php';
for ($i=0; $i<$player_cnt; $i++)
	{


$colorb=$i%2>0? '^6':'^3';
$colora=$i%2>0? '^7':'^7';

require $cpath.'ReCodMod/functions/inc_functions3.php';
if ((! $valid_id) || (! $valid_ping)) Continue; 

////////////////////////////////////////////////////////////////////////////////////////////////////
$i_namex = afdasfawf($i_name);	
  $tk = $i_id . ' / ' . $i_namex . ' / ' . $i_ip . ' / ' . $i_ping;
	$kski = explode(" / ", $tk);

if(!empty($chistx)){
if (!preg_match("/^bot\d+$/",  $chistx, $tmp2n))
{
	usleep($sleep_rcon);
if ($game_patch == 'cod1_1.1')
rcon('say ^6 '.$colorb.'#Id:'.$colorb.' '.$colora.$i_id.' '.$colorb.' Nick: '.$colorb. $colora .$i_namex. '"', '');	
else  
rcon('say ^6 '.$colorb.'#Id:'.$colorb.' '.$colora.$i_id.' '.$colorb.' Nick: '.$colorb. $colora .$i_namex. '"', '');	
   //echo $i_namex. ' "^2from:^3 '.ciity($country_name['country']['iso']." , ".$country_name['city']['name_en']);	
}}
}
	AddToLogInfo("[".$datetime."] ID: " . $i_ip . " (" . $x_namex . ") (" . $msgr . ")");    	
echo '  '.substr($tfinishh = (microtime(true) - $start),0,7);
   ++$x_stop_lp;    //return;	
//}

// if (trim($adm_ip) == $i_ipb){
//usleep($sleep_rcon);
//	rcon('tell '. $newid .' ^6  "'.$colorac.' Status:^7 ' .$i_namex. ' - '.$statuszl.'"', '');
//	                }
                    					
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 if (strpos($msgr, $ixz.'all') !== false)
    { 
 
 $x_namex = clearnamex($i_name);
$x_nickx = clearnamex($nickr);

 echo  $mmm = substr(trim($x_nickx), 0, 2);
 echo  $nnn = substr(trim($x_namex), 0, 2);
	
 if(strpos($nnn, $mmm) !== false)
	     {
$i_namex = afdasfawf($i_name);	
  $tk = $i_id . ' / ' . $i_namex . ' / ' . $i_ip . ' / ' . $i_ping;
	$kski = explode(" / ", $tk);
			  $newid = $i_id;
			  $newip2 = $i_ip;	

			  
try
  {
	   if (empty($adminlists))	  
$db = new PDO('sqlite:'.$cpath . 'ReCodMod/databases/db1.sqlite');
else
$db = new PDO('sqlite:'.$adminlists);
    $result = $db->query("SELECT * FROM x_db_admins WHERE s_adm='$newip2' ");
 		
    foreach($result as $row)
    {			  
 	
   $adm_ip  = $row['s_adm'];
    $a_grph  = $row['s_group'];
  $adm_ip = trim($adm_ip);
  $i_ipn = trim($newip2);
//////////////////GROUPS  
  if(($adminguidctl == 1) && (array_search(strtolower($guidn), $adminguids, true) !== false)|| (array_search(strtolower($i_ip), $adminIP, true) !== false)||($adm_ip == $i_ipn) && ($a_grph == 0) 
  || ($adm_ip == $i_ipn) && ($a_grph == 5)
  || ($adm_ip == $i_ipn) && ($a_grph == 555)
  || ($adm_ip == $i_ipn) && ($a_grph == 111)
  || ($adm_ip == $i_ipn) && ($a_grph == 2) )
	      { 			    	  
		echo '---'.$i_namex.'---';
++$x_number;		
		 }
	}
	
	
$result = null;
$db = NULL;
 
  }
  catch(PDOException $e)
  {
    print ' FILE:  '.__FILE__.'  Exception : '.$e->getMessage();
  }		
	
	
}

	
if ($x_number > 0){
usleep($sleep_rcon);		 	
			require $cpath.'ReCodMod/functions/inc_functions2.php';
for ($i=0; $i<$player_cnt; $i++){
require $cpath.'ReCodMod/functions/inc_functions3.php'; 
if ((! $valid_id) || (! $valid_ping)) Continue; 

$colorb=$i%2>0? '^6':'^3';
$colora=$i%2>0? '^7':'^7';
/////////////////////////////////////////////////

try
  {
 	   if (empty($adminlists))	  
$db = new PDO('sqlite:'.$cpath . 'ReCodMod/databases/db1.sqlite');
else
$db = new PDO('sqlite:'.$adminlists);
    $result = $db->query("SELECT * FROM x_db_admins WHERE s_adm='$i_ip' LIMIT 1");
 		
    foreach($result as $row)
    {	
 	
$statuszl  = $row['s_group'];	}

$sql = "SELECT * FROM x_db_admins WHERE s_adm='$i_ip' LIMIT 1";
 $stat = $db->query($sql)->fetchColumn();
if(!$stat)
{  
$statuszl = '^9Player';
}
else if ($statuszl == 0){$statuszl = '^1Admin';}
else if(($adminguidctl == 1) && (array_search(strtolower($guidn), $adminguids, true) !== false)){$statuszl = '^1Admin';}
else if ($statuszl == 1){$statuszl = '^7Clan member';}
else if ($statuszl == 111){$statuszl = '^1Developer';}
else if ($statuszl == 2){$statuszl = '^3VIP';}
else if ($statuszl == 555){$statuszl = '^2Moderator';}
else if ($statuszl == 3){$statuszl = '^2Registered';}
else if ($statuszl == 4){$statuszl = '^4PRO';}
else if ($statuszl == 5){$statuszl = '^5Special guest';}


$result = null;
$db = NULL;
  }
  catch(PDOException $e)
  {
    print ' FILE:  '.__FILE__.'  Exception : '.$e->getMessage();
  }		
	

////////////////////////////////////////////////////////////////////////////////////////////////////
$i_namex = afdasfawf($i_name);	
  $tk = $i_id . ' / ' . $i_namex . ' / ' . $i_ip . ' / ' . $i_ping;
	$kski = explode(" / ", $tk);
	
if(!empty($chistx)){

if (!preg_match("/^bot\d+$/",  $chistx, $tmp2n))
{
	usleep($sleep_rcon);	
if ($game_patch == 'cod1_1.1')
rcon('^6 '.$colorb.'#Id:'.$colorb.' '.$colora.$i_id.' '.$colorb.' '.$infoonick.': '.$colorb. $colora .$i_namex. ''.$colorb.' '.$infoostat.': ^6('.$statuszl.'^6)"', '');	
else
rcon('tell '. $idnum .' ^6 '.$colorb.'#Id:'.$colorb.' '.$colora.$i_id.' '.$colorb.' '.$infoonick.': '.$colorb. $colora .$i_namex. ''.$colorb.' '.$infoostat.': ^9('.$statuszl.'^9)"', '');	
}}

	}
	AddToLogInfo("[".$datetime."] GEO: " . $i_ip . " (" . $x_namex . ") (" . $msgr . ")");    	
echo '  '.substr($tfinishh = (microtime(true) - $start),0,7);
   ++$x_stop_lp;    //return;	
}

// if (trim($adm_ip) == $i_ipb){
//usleep($sleep_rcon);
//	rcon('tell '. $newid .' ^6  "'.$colorac.' Status:^7 ' .$i_namex. ' - '.$statuszl.'"', '');
//	                }
                    					
	

	}		
 
}		 
?>
 
	 

 
