<?php
if ($stop_lp == 0 ) {

if ($xnonev !== false ) {

$dhgsj = addslashes(hjgdtr($nickr));
echo "\n--Teamsay : [",$datetime, "] : ".$nickr." : ".$msgO;
//AddToLog1("<br/>[".$datetime."] " . $dhgsj . " : " . $msgO . "");    


$msgO = 'TEAMCHAT';	
$msgr = 'TEAMCHAT';
if (($chat_protect == 2) || ($chat_protect == 3))
require 'chat_pre_team.php';

require $cpath.'ReCodMod/functions/inc_functions2.php';
$x_number = 0;
for ($i=0; $i<$player_cnt; $i++)
	{
require $cpath.'ReCodMod/functions/inc_functions3.php';
if ((! $valid_id) || (! $valid_ping)) Continue;  

//$vipt = (array_search($chistx, $r_adm, true) !== false); 
$x_n3 = trim(clearnamex($i_name));
$x_n4 = trim(clearnamex($nivv)); 
////////////////////////////////////CHAT
 
if ($web_con == '0'){ 
list($i1p, $i2p, $i3p, $i4p) = explode('.', $i_ip); 
$ipt = (array_search($i1p.'.'.$i2p.'.'.$i3p, $r_admi, true) !== false);
require 'chat_team.php';	}
else if ($web_con == '1') { 
require 'chat_team.php';	}
////////////////////////////////////chat
	}
if (($chat_protect == 1) || ($chat_protect == 3)) {
echo'+';
 //fclose($fpX); 
$x_n4 = trim(clearnamex($nivv)); 	
$today=date('YmdHis');
$fh=fopen($log_cash."/temp0.txt" ,"w+");
fwrite($fh, $x_n4.'%'.$today);
fclose($fh);
$fh=fopen($log_cash."/temp6.txt" ,"w+");
fwrite($fh, $x_n4.'%'.$today.'%'.$msgr);
fclose($fh);
 }
//clearstatcache(); 
	
//sqlite_close($db); sqlite_close($db2); sqlite_close($db3); sqlite_close($db4);
 

 echo '  ..  '.substr($tfinishh = (microtime(true) - $start),0,7);

++$stop_lp;
 // return;
  }else
  { 
$xz_flud = true;


$dhgsj = addslashes(hjgdtr($nickr));
$msgO = $msgr;


echo "\n--say : [",$datetime, "] : ".$nickr." : ".$msgO;

					      if ((strpos($msgr,$ixz.'on ') !== false) || (strpos($msgr,$ixz.'login ') !== false) || (strpos($msgr,$ixz.'log ') !== false))
                        AddToLog1clear ("[".$datetime."] " . $dhgsj . " : " . $msgO . "");
					      else
						  {
					    AddToLog1clear ("[".$datetime."] " . $dhgsj . " : " . $msgO . "");
                        AddToLog1("<br/>[" . $datetime . "] " . $dhgsj . " : " . $msgO . "");
						  }	

 $confirm_user=0;
if (($chat_protect == 2) || ($chat_protect == 3))
require 'chat_pre.php';

require $cpath.'ReCodMod/functions/inc_functions2.php';
$x_number = 0;
for ($i=0; $i<$player_cnt; $i++)
	{
require $cpath.'ReCodMod/functions/inc_functions3.php';
if ((! $valid_id) || (! $valid_ping)) Continue; 
//$vipt = (array_search($chistx, $r_adm, true) !== false); 
$x_n3 = trim(clearnamex($i_name));
$x_n4 = trim(clearnamex($nivv)); 
////////////////////////////////////CHAT
 


if ($confirm_user == 0)
{
	
if ($deadchat == 1)	{
if (strpos($parseline, '') == false) {
if ("-_-" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("-.-" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("-,-" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("xd" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("hello" == mb_strtolower(trim(clearnamex($msgr)))){
}else if (":d" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("privet!" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("iipubet" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("privet" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("salut" == mb_strtolower(trim(clearnamex($msgr)))){
}else if ("salut!" == mb_strtolower(trim(clearnamex($msgr)))){
}else if (":0" == mb_strtolower(trim(clearnamex($msgr)))){
}else if (":)" == mb_strtolower(trim(clearnamex($msgr)))){
}else{

if ($game_patch == 'cod1_1.1')    
                       list($ixob,$originalz,$msgr) = explode('; ', $parseline);
else	
                        list($RRR,$yyy,$ttt,$originalz,$msgr) = explode(';', $parseline);	
	
	
usleep($sleep_rcon); rcon('say ^1DeadChat ~ ^2'.$originalz .'^7 : ' .$msgr, '');}
}
}

}
++$confirm_user;

if ($web_con == '0'){ 
list($i1p, $i2p, $i3p, $i4p) = explode('.', $i_ip); 
$ipt = (array_search($i1p.'.'.$i2p.'.'.$i3p, $r_admi, true) !== false);
require 'chat.php';	
}
else if ($web_con == '1') { 
require 'chat.php';	
	}
 
/* 
require 'chat/chat_full.php';
*/ 
 if (($chat_protect == 2) || ($chat_protect == 3)){
 if ($web_con == '0'){ 
list($i1p, $i2p, $i3p, $i4p) = explode('.', $i_ip); 
$ipt = (array_search($i1p.'.'.$i2p.'.'.$i3p, $r_admi, true) !== false);
require 'chat_2.php';	
}
else if ($web_con == '1') {  
require 'chat_2.php';	
	}
 }
 
if ($web_con == '0'){ 
list($i1p, $i2p, $i3p, $i4p) = explode('.', $i_ip); 
$ipt = (array_search($i1p.'.'.$i2p.'.'.$i3p, $r_admi, true) !== false);
require 'ban.php';
	
}
else if ($web_con == '1') {  
require 'ban.php';

	}
 ////////////////////////////////////BAN
	}
  ////fclose($fpX);
if (($chat_protect == 1) || ($chat_protect == 3))  {
	
$errorchck = substr((microtime(true) - $start), 0, 7);
if($errorchck <= 1)
{
	
//$msgr = 'FLUD';  
  $numxl = 0;
  if ($x_numberz == 0)
 {
	 $fhrf = file($log_cash."/temp3.txt");
foreach ($fhrf as $nd) { 
++$numxl;
}
if($numxl < 5)
{
if ($x_numberz == 0)
 {
$x_n4 = trim(clearnamex($nivv)); 	
$today=date('YmdHis');
$fh=fopen($log_cash."/temp3.txt" ,"a+");
fwrite($fh, $x_n4.'%'.$msgr.'%'.$today.'%'.$errorchck."\n");
fclose($fh);
$x_numberz = 22;
 }
}
else if($numxl > 4)
{
	  if ($x_numberz == 0)
 {
$x_n4 = trim(clearnamex($nivv)); 	
$today=date('YmdHis');
$fh=fopen($log_cash."/temp3.txt" ,"w+");
fwrite($fh, $x_n4.'%'.$msgr.'%'.$today.'%'.$errorchck."\n");
fclose($fh);
$x_numberz = 22;
 }
}
else{
	  if ($x_numberz == 0)
 {
$x_n4 = trim(clearnamex($nivv)); 	
$today=date('YmdHis');
$fh=fopen($log_cash."/temp3.txt" ,"w+");
fwrite($fh, $x_n4.'%'.$msgr.'%'.$today.'%'.$errorchck."\n");
fclose($fh);
$x_numberz = 22;	
 }
}	
 } 
}
}
//clearstatcache(); 
//	
//sqlite_close($db); sqlite_close($db2); sqlite_close($db3); sqlite_close($db4);
 
///fclose($connect);
 echo '  ..  '.substr($tfinishh = (microtime(true) - $start),0,7);
++$stop_lp;  


}}
?>
 
