<?php

if ($game_ac == '1'){
////$r_ch = trim($chistx);
echo '  -ALBA-SCREENSHOT-  ';
$vipt = (array_search($chistx, $r_adm, true) !== false);
 ////////////////////////////////////////////////////////////////////NEW DOWN AT THE LIST   
 list($nickr, $msgr) = explode(' % ', $damytext); 
   
$i_namex = chatrr($i_name);	
  $tk = $i_id . ' / ' . $i_namex . ' / ' . $i_ip . ' / ' . $i_ping;
	$kski = explode(" / ", $tk); 	
	
	while ($row = sqlite_fetch_array($sql))
	{	
   $adm_ip  = $row['s_adm'];
   $a_grp  = $row['s_group'];
   if(($adm_ip == $i_ip) && ($kski[1] == $nickr) && (($a_grp == 0) || ($a_grp == 111))) 
	      { 	  
 for ($i=0; $i<$player_cnt; $i++)
	{
require 'ReCodMod/w_functions/inc_functions3.php';
if ((! $valid_id) || (! $valid_ping)) Continue; 

list($cmv, $numm) = explode(' ', $msgr); 	
rcon('getss '. $numm .'', '');
usleep($sleep_rcon);

}	
	 	++$x_number;
        ++$x_return;
////////////////////////////////////////////////////////////////////////////////// 
/*
$time = date("dmYHis");

chdir($alba_sc_1); 
$files = glob('*.jpg');

foreach ($files as $n => $file) 
{ if(preg_match("/shot(.*?)\.jpg/",$file,$name))
   rename($file,$time.'.png'); 	}


chdir($alba_sc_c); 
$newfiles = glob('*.png');   
   
foreach ($newfiles as $n => $fil1) 
{ if(preg_match("/shot(.*?)\.png/",$fil1,$name))
  copy(preg_match("/shot(.*?)\.png/",$fil1,$name), $bir."/".$time."_x.png"); }
*/ 
//////////////////////////////////////////////////////////////////////////////////

 //return;			 
}   
   
  } 
}  else { echo" ONLY ALBA ";}
  
   
?>
 