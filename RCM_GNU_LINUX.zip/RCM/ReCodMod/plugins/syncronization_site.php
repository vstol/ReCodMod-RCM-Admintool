<?php
if ($i_ip != ''){ 
$sql = sqlite_query($db, "SELECT * FROM x_db_admins WHERE s_adm='$i_ip' LIMIT 1");  		
if (sqlite_num_rows($sql) == 0) {	

	if (($i_ping != 111) && ($i_ping != '999'))
	    {
$gi = geoip_open($cpath."ReCodMod/geoip_bases/MaxMD/GeoLiteCity.dat",GEOIP_STANDARD);
$record = geoip_record_by_addr($gi,$i_ip);
echo $xxxnw2 = ($record->country_name);

 if ($game_patch == 'cod1_1.2'){
 
echo '-'.$i_name.'-';
 usleep($sleep_rcon);
 
if ($xxxnw2 == 'Kazakhstan')
echo'';
//rcon('akick '. $i_id.' " ^73aperucmpupyuc9 uJIu IIoD JIOruHOM HA ^2http:/^2/www.recod.ru ^7 U 3AXODU"', '');
else if ($xxxnw2 == 'Uzbekistan')
echo'';
//rcon('akick '. $i_id.' " ^73aperucmpupyuc9 uJIu IIoD JIOruHOM HA ^2http:/^2/www.recod.ru ^7 U 3AXODU"', '');
else if ($xxxnw2 == 'Moldova'){
echo'';
}else if ($xxxnw2 == 'Russia'){
rcon('akick '. $i_id.' " ^73aperucmpupyuc9 uJIu IIoD JIOruHOM HA ^2http:/^2/www.recod.ru ^7 U 3AXODU"', '');
 Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD"); 
}else if ($xxxnw2 == 'Ukraine'){
//rcon('akick '. $i_id.' " ^73aperucmpupyuc9 uJIu IIoD JIOruHOM HA ^2http:/^2/www.recod.ru ^7 U 3AXODU"', '');
// Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD"); 
echo'';
}else if ($xxxnw2 == 'Belarus'){
//rcon('akick '. $i_id.' " ^73aperucmpupyuc9 uJIu IIoD JIOruHOM HA ^2http:/^2/www.recod.ru ^7 U 3AXODU"', '');
// Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD"); 
echo'';
}else{
//rcon('akick '. $i_id.' " ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7and come back!"', '');
 //echo'-none-';

}
 
 }
 else{
 
 $reclama[0]='1'; 
 $reclama[1]='2'; 
 $reclama[2]='3'; 
 $reclama[3]='4';
 $zz=rand(0,3); 
 echo '-'.$i_name.'-';


if ($xxxnw2 == 'United Kingdom'){

if ($i_ip != ''){ if ($zz == '2'){ usleep($sleep_rcon);
rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
usleep(1700000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");}}

}
else if ($xxxnw2 == 'Germany-----')
{

if ($i_ip != ''){ if ($zz == '2'){ usleep($sleep_rcon);
rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
usleep(1700000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");}} 

}
else if ($xxxnw2 == 'Poland----')
{

if ($i_ip != ''){ if ($zz == '2'){ usleep($sleep_rcon);
rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
usleep(1700000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");}} 

}
else if ($xxxnw2 == 'United States')
{

usleep($sleep_rcon); rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
 usleep(2000000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");  

}
else if ($xxxnw2 == 'Canada')
{

if ($i_ip != ''){ if ($zz == '2'){ usleep($sleep_rcon);
rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
usleep(1700000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");}} 

}
else if ($xxxnw2 == 'Ukraine')
{

usleep($sleep_rcon); rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
 usleep(2000000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");  

}
else if ($xxxnw2 == 'Russia')
{

usleep($sleep_rcon); rcon('say ^6 '.$i_name.' ^7REGISTER or LOGIN PLEASE @ ^2http:/^2/www.recod.ru ^7AND COME BACK!', '');
 usleep(2000000);  rcon('clientkick '. $i_id, '');
Addregggx("[".$datetime."] UNREGISTERED: " . $i_ip . " (" . $i_name . ")  (" . $xxxnw2. ")   reason: RECOD");   

}
else 
{

echo ' - ';

}
 


 
 }
 

  	
echo '  '.substr($tfinishh = (microtime(true) - $start),0,7);
	                       }
   }}
?>
 
