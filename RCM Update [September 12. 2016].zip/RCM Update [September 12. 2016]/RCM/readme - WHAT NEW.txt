IN cfg/bans.cfg/php

CIDR bans support
And special ban ranges
Included taht support in !range (example !range 230.168.1.0-230.168.1.100 CheaterNAME) command and manual ban

// Manual ip ban
// *Until 1000
/*
RANGE SUPPORT  $rules_super_range[] = '230.168.1.0-230.168.1.100';
RANGE SUPPORT  $rules_super_range[] = '230.168.*.*';
CIDR SUPPORT   $rules_super_range[] = '230.168.0.0/16'; 
*/
 $rules_kick_ip_super_range = true;  // true - on , false - off
 $rules_super_range[] = '230.168.0.0/16'; 
 $rules_super_range[] = '230.168.0.0/24'; 